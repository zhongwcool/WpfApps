#ifndef DEMODLL2_LIBRARY_H
#define DEMODLL2_LIBRARY_H

#include <string>

extern "C" __declspec(dllexport) int hello();

extern "C" __declspec(dllexport) void SayHello(char* str, int strlen);

#endif //DEMODLL2_LIBRARY_H
