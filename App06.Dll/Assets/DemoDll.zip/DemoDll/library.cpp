#include "library.h"

#include <iostream>
#include <ctime>
#include <windows.h>

using namespace std;

int hello() {
    int result = 0;
    for(int i = 0; i < 100; i++) {
        Sleep(100);
        result += i;
    }

    return result;
}

void SayHello(char* str, int strlen) {
    string data = "Across the great wall, we can get reach every corner int the world!";
    cout << data << endl;

    time_t t = time(0);
    char buffer[64];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&t)); //��-��-�� ʱ-��-��
    cout << buffer << endl;

    data.append("\n").append(buffer);

    copy(data.begin(), data.end(), str);
    str[min(strlen - 1, (int)data.size())] = 0;
}