#include "library.h"

#include <iostream>
#include <ctime>
#include <windows.h>

using namespace std;

int hello() {
    int result = 0;
    for(int i = 0; i < 100; i++) {
        Sleep(100);
        result += i;
    }

    return result;
}

void SayHello(char* str, int strlen) {
    string data = "Across the great wall, we can get reach every corner int the world!";
    cout << data << endl;

    // 获取当前时间
    time_t currentTime;
    time(&currentTime);

    // 将时间转换为可打印的自定义格式字符串
    char timeString[100];
    struct tm timeInfo{};
    localtime_s(&timeInfo, &currentTime);
    strftime(timeString, sizeof(timeString), "%Y-%m-%d %H:%M:%S", &timeInfo);
    cout << timeString << endl;

    data.append("\n").append(timeString);

    copy(data.begin(), data.end(), str);
    str[min(strlen - 1, (int)data.size())] = 0;
}